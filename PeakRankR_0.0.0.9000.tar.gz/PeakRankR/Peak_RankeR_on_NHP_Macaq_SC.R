setwd("/allen/programs/celltypes/workgroups/rnaseqanalysis/sarojaS/230418_PeakRanker_package/PeakRankeR_2023-06-08/PeakRankeR/R/")

# library to run PeakRankeR
library(bedtoolsr)
library(data.table)
library(dplyr)
library(rtracklayer)


# Reading in the file with peak coordinates and groups 
tsv_file <- read.csv("/allen/programs/celltypes/workgroups/rnaseqanalysis/sarojaS/230418_PeakRanker_package/PeakRankeR/test/Subclass_annotated_markerPeaks_mouse.tsv", sep = "\t", header = TRUE)

subset_tsv_file <- tsv_file %>%
  group_by(cell.population) %>%
  dplyr::slice(1:2)

# sourcing the functions
source("./Peak_MACS2_rank.R")
source("./Peak_intersect_rank.R")
source("./multiBigwig_summary_SS.R")
source("./Peak_coverage_rank.R")
source("./PeakRankeR.R")

# for mouse
bw_table <- read.table("/allen/programs/celltypes/workgroups/rnaseqanalysis/sarojaS/20221113_ATAC_PPt_R_package/Spinal_cord/221222_PeakRanker/bwfiles/bw_tables", header = TRUE)
bw_table$sample_id <- sort(unique(tsv_file$cell.population))


################################################################################################################
start <- Sys.time()
result_sub <- Peak_RankeR(tsv_file,"cell.population",unique(tsv_file$cell.population),bw_table, TRUE,c(1,1,1))
print( Sys.time() - start)
# Time difference of 8.013778 mins

devtools::document()
